export default {
  container: {
    backgroundColor: "#FBFAFA"
  }
};
