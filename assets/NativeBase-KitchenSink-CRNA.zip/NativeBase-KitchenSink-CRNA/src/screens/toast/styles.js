export default {
  container: {
    backgroundColor: "#fff"
  },
  mb15: {
    marginTop: 15
  }
};
