# [2.4.0]

#### Upgraded Features

*	Upgraded NativeBase from 2.3.5 to 2.3.10
*	Upgraded React from 16.0.0 to 16.2.0
*	Upgraded React Native from 0.50.1o 0.52.0
*	Upgraded Expo from 23.0.1 to 25.0.0
*	Upgraded React-Navigation 1.0.0-beta.19 to 1.5.0
*   Ejected new theme from NativeBase 2.3.10
*   Upgraded dev-dependencies
